Steps for Database Creation and Duplication
-------------------------------

This repository contains the starter code for group 11's database. In order to
duplicate the database follow the following steps. 
1. Clone the repository 
2. Make sure the repository is saved in the '/home/lion/' directory.
2. In the terminal run the file create-table.sql, this populates the database and 
   creates all the tables for our database (group 11). 
3. In the terminal run the file DML-queries.sql, this runs the queries for our database. 
